# ubc-aerodesign
PyPi package for utilities used by the UBC AeroDesign student team.

Internal docs for how to publish to Pypi:
https://docs.google.com/document/d/1yASxyw1zxSDgzlERRhHkX3TrrKrpSkeKY7EFy2kpUSg/edit#heading=h.rkdknaqpdl6f